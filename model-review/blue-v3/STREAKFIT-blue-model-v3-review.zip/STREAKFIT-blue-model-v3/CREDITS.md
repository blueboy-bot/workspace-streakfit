# 资产来源与许可

基础网格及体型目标：MakeHuman Community，hm08。
官方仓库：https://github.com/makehumancommunity/makehuman
所用提交：a8bc2d54ff0ac92e78ff71431b1023eda42bf482。

使用的是仓库中 `makehuman/data/3dobjs/base.obj` 和
`makehuman/data/targets/` 的图形资产，官方声明许可为 **CC0 1.0 Universal**。
原始许可全文随文件保存为 `LICENSE-MAKEHUMAN-ASSETS.md`。

资产头部记载原作者及贡献者：Manuel Bastioni、Data Collection AB、
Joel Palmius、Jonas Hauquier 等 MakeHuman 团队成员。
MakeHuman 程序代码本身使用 AGPL；本次脚本没有复制其程序逻辑，
仅解析并调整其 CC0 数据资产。完整仓库许可声明保存在 source/makehuman。

形体改造、蓝色材质、无五官头部及灯光构图：本 STREAKFIT 静态样片制作。
用户三视图仅为外观参考，不宣称已获得该图片原始三维模型。

本次静态角色不使用 Z-Anatomy 原始网格；旧项目的图谱许可与来源文件保留。
视频链接未实际访问成功，没有提取或复制其画面与模型。

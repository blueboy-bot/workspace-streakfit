"""Static reference-inspired muscular character. CC0 mesh assets; no animation.

This is a stylized reconstruction from a reference image, not an exact recovery
of its original 3D asset and not an anatomical/biomechanical certification.
"""
import bpy, bmesh, math, json, sys
import numpy as np
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
DATA = ROOT / 'source/makehuman/makehuman/data'
vertices = []; groups = {}; group = None
for line in (DATA/'3dobjs/base.obj').read_text().splitlines():
    if line.startswith('v '): vertices.append([float(v) for v in line.split()[1:4]])
    elif line.startswith('g '): group=line[2:]; groups.setdefault(group, [])
    elif line.startswith('f ') and group:
        groups[group].append([int(v.split('/')[0])-1 for v in line.split()[1:]])
co=np.asarray(vertices, dtype=np.float64)
applied=[]
def target(name, weight):
    path=DATA/'targets'/name
    for line in path.read_text().splitlines():
        if not line or line.startswith('#'): continue
        values=line.split()
        co[int(values[0])] += np.asarray(values[1:4], dtype=float)*weight
    applied.append({'asset':name,'weight':weight})

for ethnicity in ['caucasian','asian','african']:
    target('macrodetails/'+ethnicity+'-male-young.target', 1/3)
target('macrodetails/universal-male-young-maxmuscle-averageweight.target', .80)
target('macrodetails/universal-male-young-maxmuscle-minweight.target', .20)
target('macrodetails/proportions/male-young-maxmuscle-averageweight-idealproportions.target', .22)
for name, weight in [('torso/torso-muscle-pectoral-incr.target',.42),
                     ('torso/torso-muscle-dorsi-incr.target',.30),
                     ('torso/torso-vshape-incr.target',.12),
                     ('stomach/stomach-tone-incr.target',.65),
                     ('buttocks/buttocks-volume-decr.target',.20)]: target(name,weight)
for side in ['l','r']:
    for limb, weight in [('upperarm',.48),('upperarm-shoulder',.18),('lowerarm',.23),('upperleg',.30),('lowerleg',.22)]:
        target(f'armslegs/{side}-{limb}-muscle-incr.target',weight)

# MakeHuman: Y-up, Z-front, decimetres. Blender: Z-up, -Y-front, metres.
co=co[:,[0,2,1]] * np.asarray([.1,-.1,.1])
body_ids=np.unique(np.concatenate(groups['body']))
floor=co[body_ids,2].min(); co[:,2]-=floor
scale=1.80/co[body_ids,2].max(); co*=scale
landmarks={name:co[np.unique(np.concatenate(faces))].mean(axis=0).tolist()
           for name,faces in groups.items() if name.startswith('joint-')}
# Reference pose: relaxed arms close to the trunk, rather than the base A pose.
def smoothstep(value):
    t=np.clip(value,0,1); return t*t*(3-2*t)
forearm_original=co.copy()
for sign, side in [(1,'l'),(-1,'r')]:
    elbow=np.asarray(landmarks['joint-'+side+'-elbow'])
    shoulder=np.asarray(landmarks['joint-'+side+'-shoulder'])
    wrist=np.asarray(landmarks['joint-'+side+'-hand'])
    axis=wrist-elbow; length=np.linalg.norm(axis); axis/=length
    desired=elbow-shoulder; desired/=np.linalg.norm(desired)
    rot=np.asarray(Vector(axis.tolist()).rotation_difference(Vector(desired.tolist())).to_matrix())
    projection=(forearm_original-elbow)@axis/length
    weight=smoothstep((projection+.03)/.18)*smoothstep((sign*forearm_original[:,0]-.285)/.09)
    rotated=(forearm_original-elbow)@rot.T+elbow
    co+=(rotated-forearm_original)*weight[:,None]
original=co.copy()
for sign, side in [(1,'l'),(-1,'r')]:
    pivot=np.asarray(landmarks['joint-'+side+'-shoulder'])
    angle=sign*math.radians(25)
    rot=np.asarray([[math.cos(angle),0,math.sin(angle)],[0,1,0],[-math.sin(angle),0,math.cos(angle)]])
    outer=smoothstep((sign*original[:,0]-.28)/.04)
    upper=smoothstep((original[:,2]-1.12)/.06)
    weight=smoothstep((sign*original[:,0]-.165)/.11)*(upper+(1-upper)*outer)
    rotated=(original-pivot)@rot.T+pivot
    co+=(rotated-original)*weight[:,None]
leg_weight=smoothstep((.98-co[:,2])/.20)
leg_factor=np.clip(.64+.36*co[:,2]/.95,.64,1)
co[:,0]*=1-leg_weight*(1-leg_factor)
(OUT/'source-morphs.json').write_text(json.dumps({'height_m':1.80,'targets':applied,'landmarks':landmarks},indent=2))

bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene

# Keep only the visible body skin, not helper cages, tongue, eyes or joint markers.
faces=groups['body']
used=np.unique(np.concatenate(faces)); mapping={old:i for i,old in enumerate(used)}
mesh=bpy.data.meshes.new('Continuous human body topology')
mesh.from_pydata(co[used].tolist(),[],[[mapping[i] for i in f] for f in faces]); mesh.update()
body=bpy.data.objects.new('Blue muscular body · reference reconstruction',mesh)
scene.collection.objects.link(body); bpy.context.view_layer.objects.active=body; body.select_set(True)
sub=body.modifiers.new('Refine continuous muscle surfaces','SUBSURF'); sub.levels=2
bpy.ops.object.modifier_apply(modifier=sub.name)

if '--raw' not in sys.argv:
    # Replace the detailed face with a closed, jaw-shaped featureless head.
    bm=bmesh.new(); bm.from_mesh(body.data)
    bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.co.z>1.590],context='VERTS')
    boundary=[e for e in bm.edges if e.is_boundary]
    bmesh.ops.holes_fill(bm,edges=boundary,sides=0)
    bm.to_mesh(body.data); bm.free()
    profile=[(1.465,.040,.033,0),(1.50,.048,.057,-.002),
             (1.535,.047,.059,-.006),(1.56,.054,.064,-.012),
             (1.59,.067,.074,-.022),(1.63,.080,.082,-.026),
             (1.68,.084,.083,-.025),(1.72,.079,.078,-.022),
             (1.75,.068,.066,-.020),(1.78,.047,.045,-.020),
             (1.790,.034,.032,-.020),(1.796,.021,.020,-.020),
             (1.799,.0105,.010,-.020),(1.800,.001,.001,-.020)]
    vv=[]; ff=[]; rings=150; sides=96
    zs=np.asarray([p[0] for p in profile])
    # Smooth interpolation using Catmull-like cubic Hermite slopes.
    def interp(z, column):
        vals=np.asarray([p[column] for p in profile]); j=int(np.clip(np.searchsorted(zs,z)-1,0,len(zs)-2))
        slopes=np.gradient(vals,zs); h=zs[j+1]-zs[j]; t=(z-zs[j])/h
        return (2*t**3-3*t*t+1)*vals[j]+(t**3-2*t*t+t)*h*slopes[j]+(-2*t**3+3*t*t)*vals[j+1]+(t**3-t*t)*h*slopes[j+1]
    # The atlas-style head leaves a lower-jaw fragment below a horizontal cut.
    # Move that fragment inside the new skin envelope before unioning, so it
    # cannot appear as a mouth-like ridge or a flat seam around the neck.
    for vertex in body.data.vertices:
        z=vertex.co.z
        if z<=1.510: continue
        w,d,c=[interp(z,i) for i in [1,2,3]]
        x,y=vertex.co.x,vertex.co.y
        radial=math.sqrt((x/w)**2+((y-c)/d)**2)
        if radial>1:
            blend=float(smoothstep((z-1.510)/.025))
            f=1-blend+blend*.985/radial
            vertex.co.x=x*f; vertex.co.y=c+(y-c)*f
    for z in np.linspace(profile[0][0],profile[-1][0],rings):
        w,d,c=[interp(z,i) for i in [1,2,3]]
        for k in range(sides):
            angle=2*math.pi*k/sides
            vv.append((w*math.cos(angle),c+d*math.sin(angle),float(z)))
    for j in range(rings-1):
        for k in range(sides):
            a=j*sides+k; b=j*sides+(k+1)%sides; ff.append((a,b,b+sides,a+sides))
    ff.append(tuple(reversed(range(sides)))); ff.append(tuple((rings-1)*sides+k for k in range(sides)))
    m=bpy.data.meshes.new('Featureless anatomical head profile'); m.from_pydata(vv,[],ff); m.update()
    head=bpy.data.objects.new('Featureless head',m); scene.collection.objects.link(head)
    parts=[body,head]
    for sign in [-1,1]:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=16,location=(sign*.080,.020,1.658))
        ear=bpy.context.object; ear.name='Subtle ear'; ear.scale=(.011,.018,.030)
        bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); parts.append(ear)
    bpy.ops.object.select_all(action='DESELECT')
    for obj in parts: obj.select_set(True)
    bpy.context.view_layer.objects.active=body; bpy.ops.object.join()
    body.data.remesh_voxel_size=.0023
    bpy.ops.object.voxel_remesh()
    sm=body.modifiers.new('Smooth continuous skin transitions','SMOOTH'); sm.factor=.42; sm.iterations=3
    bpy.ops.object.modifier_apply(modifier=sm.name)
    neck_group=body.vertex_groups.new(name='Smooth neck transition')
    for vertex in body.data.vertices:
        z=vertex.co.z
        if 1.445<z<1.625:
            weight=float(smoothstep((z-1.445)/.04)*smoothstep((1.625-z)/.04))
            neck_group.add([vertex.index],weight,'REPLACE')
    neck_smooth=body.modifiers.new('Remove tiny neck union ridges','SMOOTH')
    neck_smooth.vertex_group=neck_group.name; neck_smooth.factor=.7; neck_smooth.iterations=60
    bpy.ops.object.modifier_apply(modifier=neck_smooth.name)
    # Sculpt shallow anatomical relief directly into the continuous human skin.
    # These are artistic contours, not separate spheres or muscle activation data.
    n=len(body.data.vertices); arr=np.empty(n*3,dtype=np.float32)
    body.data.vertices.foreach_get('co',arr); arr=arr.reshape((-1,3))
    x,y,z=arr.T; ax=np.abs(x)
    def bump(cx,cz,rx,rz):
        return np.exp(-2*((ax-cx)/rx)**2-2*((z-cz)/rz)**2)
    front_mask=smoothstep((-y-.012)/.050)
    back_mask=smoothstep((y-.010)/.050)
    front=.018*bump(.104,1.352,.093,.074)
    front-=.005*bump(.103,1.298,.084,.011)
    front-=.003*bump(0,1.35,.012,.087)
    for az in [1.235,1.168,1.102]:
        front+=.008*bump(.034,az,.035,.031)
    for az in [1.201,1.134,1.070]:
        front-=.0015*bump(.035,az,.053,.009)
    front-=.0025*bump(0,1.175,.009,.133)
    front+=.0045*bump(.092,1.16,.029,.12)
    front+=.009*bump(.286,1.267,.039,.094)
    front+=.004*bump(.338,1.045,.030,.082)
    front+=.009*bump(.126,.792,.052,.150)
    front+=.005*bump(.085,.615,.032,.063)
    front-=.0025*bump(.133,.75,.009,.123)
    back=.013*bump(.145,1.306,.081,.148)
    back+=.010*bump(.052,1.433,.047,.076)
    back+=.007*bump(.078,1.367,.049,.074)
    back+=.006*bump(.030,1.160,.026,.133)
    back-=.005*bump(0,1.287,.012,.197)
    back+=.009*bump(.298,1.273,.042,.093)
    back+=.006*bump(.127,.356,.043,.095)
    arr[:,1]=y-front*front_mask+back*back_mask
    # Suppress nipple protrusions with a broad, softly blended local treatment.
    # The base mesh has no external penis asset; no such asset is loaded or added.
    body.data.vertices.foreach_set('co',arr.ravel()); body.data.update()
    bm=bmesh.new(); bm.from_mesh(body.data)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces)); bm.to_mesh(body.data); bm.free()

for p in body.data.polygons: p.use_smooth=True
body['purpose']='Static appearance review; not rigged or animated'
body['source_assets']='MakeHuman bundled CC0 hm08 topology and muscle targets'
body['reference']='User supplied blue front/side/back image. Original reference mesh unavailable.'

mat=bpy.data.materials.new('Matte blue · teaching model'); mat.diffuse_color=(.25,.49,.78,1)
mat.use_nodes=True; bs=mat.node_tree.nodes.get('Principled BSDF')
bs.inputs['Base Color'].default_value=(.25,.49,.78,1); bs.inputs['Roughness'].default_value=.56
bs.inputs['Metallic'].default_value=0; bs.inputs['Subsurface Weight'].default_value=.025
body.data.materials.clear(); body.data.materials.append(mat)

# Render configuration: soft neutral studio, one actual model, 3 cameras.
scene.render.engine='BLENDER_WORKBENCH'; scene.render.resolution_x=768; scene.render.resolution_y=1200
scene.render.resolution_percentage=100; scene.render.image_settings.file_format='PNG'
sh=scene.display.shading; sh.light='STUDIO'; sh.studiolight_rotate_z=.25
sh.studio_light='paint.sl'; sh.color_type='MATERIAL'; sh.show_shadows=True
sh.show_cavity=True; sh.cavity_type='WORLD'; sh.curvature_ridge_factor=1.2; sh.curvature_valley_factor=1.0
sh.cavity_ridge_factor=.6; sh.cavity_valley_factor=.7
sh.show_specular_highlight=False; sh.background_type='WORLD'; scene.world.color=(.92,.93,.94)
scene.display.render_aa='16'; scene.view_settings.view_transform='Standard'
cameras=[]
for name,location in [('front',(0,-5,.91)),('side',(-5,0,.91)),('back',(0,5,.91))]:
    data=bpy.data.cameras.new(name.title()+' orthographic'); cam=bpy.data.objects.new(name.title()+' camera',data)
    scene.collection.objects.link(cam); cam.location=location
    cam.rotation_euler=(Vector((0,0,.91))-cam.location).to_track_quat('-Z','Y').to_euler()
    data.type='ORTHO'; data.ortho_scale=2.02; cameras.append(cam)
scene.camera=cameras[0]
body.select_set(True); bpy.context.view_layer.objects.active=body
for area in bpy.context.screen.areas if bpy.context.screen else []:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=2.65
        area.spaces.active.region_3d.view_location=(0,0,.9)
        area.spaces.active.overlay.show_overlays=False
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'STREAKFIT-blue-model-v3.blend'))
for cam,name in zip(cameras,['front','side','back']):
    scene.camera=cam; scene.render.filepath=str(OUT/(name+'.png')); bpy.ops.render.render(write_still=True)
print('STATIC MODEL AND THREE VIEWS COMPLETE',len(body.data.vertices),len(body.data.polygons),flush=True)

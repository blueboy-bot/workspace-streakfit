"""Compose labels around a real Blender render and package review artifacts."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import base64,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'
src=Image.open(OUT/'studio-three-view.png').convert('RGBA')
back=Image.new('RGBA',src.size,'white'); back.alpha_composite(src); rgb=back.convert('RGB')
font_root=ROOT.parent/'blue-mannequin-v2/fonts'
regular=ImageFont.truetype(str(font_root/'StreakfitMotionSans-Regular.otf'),34)
bold=ImageFont.truetype(str(font_root/'StreakfitMotionSans-Bold.otf'),40)
sheet=Image.new('RGB',(2304,1650),'white');sheet.paste(rgb,(0,0));d=ImageDraw.Draw(sheet)
for text,x in [('FRONT',516),('SIDE',1152),('BACK',1788)]:
    d.text((x,1538),text,font=bold,fill='#465466',anchor='mt')
d.text((1152,1600),'STREAKFIT  /  MODEL STUDY 03',font=regular,fill='#8090a0',anchor='mt')
sheet.save(OUT/'model-three-view.png')
sheet.resize((1536,1100),Image.Resampling.LANCZOS).save(OUT/'model-three-view-review.jpg',quality=94)
# Standalone forwarding page, with no CDNs or missing external image requests.
data=base64.b64encode((OUT/'model-three-view-review.jpg').read_bytes()).decode()
html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>STREAKFIT 蓝色三维模型</title><style>body{margin:0;background:#f5f7fa;color:#25364a;font:17px/1.65 system-ui,sans-serif}main{max-width:1300px;margin:auto;padding:24px}h1{font-size:24px}img{width:100%;height:auto;border-radius:16px;background:white}p{max-width:800px}small{color:#66778a}</style><main><h1>STREAKFIT · 蓝色人体模型</h1><p>静态外观审阅：正面、侧面、背面。确认体型与肌群轮廓后，再制作教学动画。</p><img alt="蓝色模型的正面、侧面、背面" src="data:image/jpeg;base64,DATA"><p><small>由真实 Blender 网格渲染。根据图片参考重建，尚未通过用户外观验收；本版尚未绑定动画骨架。</small></p></main></html>'''.replace('DATA',data)
(OUT/'preview.html').write_text(html)
manifest={}
for name in ['STREAKFIT-blue-model-v3.blend','model-three-view.png','model-three-view-review.jpg','preview.html','MODEL-QA.json','source-morphs.json','README.md','CREDITS.md','LICENSE-MAKEHUMAN-ASSETS.md']:
    p=OUT/name;manifest[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(OUT/'delivery-manifest.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(OUT/'STREAKFIT-blue-model-v3-review.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in [*manifest,'delivery-manifest.json','PROGRESS.md']: z.write(OUT/name,arcname='STREAKFIT-blue-model-v3/'+name)
    for name in ['build_model.py','render_studio.py','verify_model.py','finish_delivery.py']:z.write(ROOT/name,arcname='STREAKFIT-blue-model-v3/scripts/'+name)
    z.write(ROOT/'source/used-assets-manifest.json',arcname='STREAKFIT-blue-model-v3/source/used-assets-manifest.json')
    z.write(ROOT/'tools/oidn-source.json',arcname='STREAKFIT-blue-model-v3/source/oidn-source.json')
with zipfile.ZipFile(OUT/'STREAKFIT-blue-model-v3-review.zip') as z:assert z.testzip() is None
print(json.dumps(manifest,indent=2))

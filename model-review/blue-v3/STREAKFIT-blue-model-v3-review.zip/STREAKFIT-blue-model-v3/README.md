# STREAKFIT 蓝色人体模型 · 静态外观审阅版

本次范围：根据用户提供的蓝色正面、侧面、背面图片制作可编辑三维模型，
先交付静态效果图，等待用户确认外形，再继续教学动画。

## 文件

- `STREAKFIT-blue-model-v3.blend`：实际连续人体网格、蓝色材质、三台正交相机和柔光灯。
- `model-three-view.png`：由 Blender 实际网格渲染的静态三视图，白色背景。
- `preview.html`：嵌入静态图，可单独转发，不依赖外部图片地址。
- `source-morphs.json`：人体体型 morph 设置及原始关节参考位置。
- `MODEL-QA.json`：实际 Blender 网格与模型文件检查。
- `CREDITS.md` / `LICENSE-MAKEHUMAN-ASSETS.md`：基础网格来源和 CC0 许可。

## 制作范围与限制

使用 MakeHuman 的 hm08 连续人体网格与成年男性、肌肉、低脂和局部体型资产，
根据蓝色三视图进行造型调整；面部简化、外部生殖器资产未导入。
保留一体化肩、肘、髋、膝以及实际人体手指和脚趾形状，
皮肤表面为连续网格，肌群轮廓雕刻在同一个表面中。

这是图片参考下的造型重建，不是原图模型文件的精确恢复。
目标是供用户审核体型与风格，尚未获得用户外观验收，也未经过专业解剖认证。
本文件尚未绑定动画骨架或制作动作；后续变形需要独立检查。
Yellow Dude 链接已记录，但由于当前环境网络阻止 YouTube，未实际观看视频。
本次外观直接以用户提供的蓝色三视图为参考，不宣称复刻视频模型。

模型单位：米；目标全身高度约 1.80 米。高度是造型尺度，不是用户身高。
高密度皮肤适合雕刻和渲染；正式运动动画前需检查拓扑及肩髋关节变形。
旧版场景、源图谱、视频和检查点均保留。本次没有制作新教学视频或修改 App。

## 恢复制作

在 Blender 4.3.2 中打开 `.blend`。
默认显示一名人物，Front / Side / Back camera 为单人物查看相机。
静态三视图由 `render_studio.py` 临时生成共享同一网格的三个渲染实例；
不会把三个实例作为三个不同模型保存到正式文件。

从本目录上一层执行：

```bash
XDG_CACHE_HOME=/tmp/streakfit-blender-cache blender -b --disable-autoexec --python-exit-code 1 --python build_model.py
XDG_CACHE_HOME=/tmp/streakfit-blender-cache blender -b --disable-autoexec output/STREAKFIT-blue-model-v3.blend --python-exit-code 1 --python render_studio.py
python finish_delivery.py
```

渲染脚本会清理自己生成的灯光与地板，可在该模型上重新执行。
降噪使用工作目录中已核验的官方 OIDN 原生工具，其来源与校验值保存在 `tools/`。
打包中的脚本作为制作记录；完整源数据、字体及渲染工具保存在工作区。
单独转发的 `.blend` 与预览网页不依赖这些外部制作文件。

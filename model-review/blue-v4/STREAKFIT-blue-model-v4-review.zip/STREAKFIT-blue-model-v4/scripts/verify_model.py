"""Validate the actual saved static mesh; never certify motion or anatomy."""
import bpy,bmesh,json,math,hashlib
import numpy as np
from pathlib import Path
from mathutils import Vector
from mathutils.kdtree import KDTree
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'
body=bpy.data.objects['Blue muscular body · reference reconstruction']
a=np.empty(len(body.data.vertices)*3,dtype=np.float32); body.data.vertices.foreach_get('co',a); a=a.reshape((-1,3))
bm=bmesh.new(); bm.from_mesh(body.data); bm.verts.ensure_lookup_table()
unseen=set(bm.verts); components=[]
while unseen:
    start=unseen.pop(); stack=[start]; n=1
    while stack:
        v=stack.pop()
        for edge in v.link_edges:
            w=edge.other_vert(v)
            if w in unseen:unseen.remove(w);stack.append(w);n+=1
    components.append(n)
boundary=sum(e.is_boundary for e in bm.edges); bad=sum(not e.is_manifold for e in bm.edges)
tree=KDTree(len(a))
for i,p in enumerate(a):tree.insert(p,i)
tree.balance(); sample=a[::71]; errors=[]
for x,y,z in sample: errors.append(tree.find(Vector((-float(x),float(y),float(z))))[2])
mat=body.data.materials[0]; color=list(mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value)
checks={'finite_vertices':bool(np.isfinite(a).all()),'one_connected_skin':len(components)==1,
        'closed_manifold_edges':boundary==0 and bad==0,'height_within_5mm':abs(float(np.ptp(a[:,2]))-1.80)<.005,
        'one_blue_material':len(body.data.materials)==1 and color[2]>color[1]>color[0],
        'single_character':{o.name for o in bpy.data.objects if o.type=='MESH'}=={body.name,'White studio floor'},
        'no_animation':body.animation_data is None,'no_bone_objects':all(o.type!='ARMATURE' for o in bpy.data.objects),
        'front_side_back_cameras':all(n+' camera' in bpy.data.objects for n in ['Front','Side','Back'])}
qa={'scope':'Static geometry and file validation only. User appearance acceptance pending.',
    'vertices':len(a),'polygons':len(body.data.polygons),'dimensions_m':np.ptp(a,axis=0).tolist(),
    'connected_components':components,'boundary_edges':boundary,'non_manifold_edges':bad,
    'sampled_bilateral_surface_error_max_m':max(errors),'blue_base_color_linear_rgba':color,
    'checks':checks,'all_technical_checks_pass':all(checks.values()),
    'not_tested':['Exact reproduction of reference asset','Professional anatomy review','Rigging or skin deformation','Motion biomechanics','User visual acceptance']}
(OUT/'MODEL-QA.json').write_text(json.dumps(qa,indent=2))
assert all(checks.values()),qa
print(json.dumps(qa,indent=2),flush=True)

"""Render actual Blender geometry in a soft studio; no image generation."""
import bpy, math, sys, subprocess
import numpy as np
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'
scene=bpy.context.scene
body=bpy.data.objects['Blue muscular body · reference reconstruction']
body.hide_render=False
for ob in list(bpy.data.objects):
    if ob.name.startswith(('White studio floor','Large soft key','Soft fill','Top and rear rim','Review ','Three-view review camera')):
        bpy.data.objects.remove(ob,do_unlink=True)
scene.render.engine='CYCLES'; scene.cycles.device='CPU'; scene.cycles.samples=48
scene.cycles.use_denoising=False
scene.cycles.max_bounces=5; scene.cycles.diffuse_bounces=3
scene.render.resolution_x=2304; scene.render.resolution_y=1536
scene.render.resolution_percentage=50 if '--draft' in sys.argv else 100
scene.render.image_settings.file_format='PNG'; scene.render.image_settings.color_mode='RGBA'; scene.render.film_transparent=True
scene.view_settings.view_transform='AgX'; scene.view_settings.look='AgX - Medium High Contrast'
scene.view_settings.exposure=-.25
scene.world.use_nodes=True
world=scene.world.node_tree.nodes.get('Background'); world.inputs['Color'].default_value=(.78,.84,.94,1)
world.inputs['Strength'].default_value=.12

mat=body.data.materials[0]; bs=mat.node_tree.nodes.get('Principled BSDF')
bs.inputs['Base Color'].default_value=(.12,.34,.70,1)
bs.inputs['Roughness'].default_value=.48
bs.inputs['Subsurface Weight'].default_value=.035
bs.inputs['Specular IOR Level'].default_value=.30
mat.diffuse_color=(.12,.34,.70,1)

bpy.ops.mesh.primitive_plane_add(size=10,location=(0,0,-.004))
floor=bpy.context.object; floor.name='White studio floor'
floor.is_shadow_catcher=True
fm=bpy.data.materials.new('Neutral white floor'); fm.use_nodes=True
fb=fm.node_tree.nodes.get('Principled BSDF'); fb.inputs['Base Color'].default_value=(.86,.88,.90,1); fb.inputs['Roughness'].default_value=.80
floor.data.materials.append(fm)
def area(name,position,energy,size,target=(0,0,1.0)):
    d=bpy.data.lights.new(name,'AREA'); d.energy=energy; d.shape='DISK'; d.size=size
    ob=bpy.data.objects.new(name,d); scene.collection.objects.link(ob); ob.location=position
    ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
area('Large soft key',(-3,-4,4.8),450,2.8)
area('Soft fill',(3,-2,2.8),75,3)
area('Top and rear rim',(0,2.5,4),280,2.5)

# Save editable single-character scene before making linked review duplicates.
scene.camera=bpy.data.objects['Front camera']
for area in bpy.context.screen.areas if bpy.context.screen else []:
    if area.type=='VIEW_3D':
        space=area.spaces.active; space.shading.type='SOLID'; space.shading.color_type='MATERIAL'
        space.shading.light='STUDIO'; space.shading.studio_light='paint.sl'; space.shading.show_shadows=False
        space.overlay.show_overlays=False
        space.region_3d.view_rotation=scene.camera.rotation_euler.to_quaternion()
        space.region_3d.view_perspective='ORTHO'; space.region_3d.view_distance=2.40
        space.region_3d.view_location=(0,0,.91)
bpy.data.objects['Side camera'].location=(-5,0,.91)
cam=bpy.data.objects['Side camera']; cam.rotation_euler=(Vector((0,0,.91))-cam.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.select_all(action='DESELECT'); body.select_set(True); bpy.context.view_layer.objects.active=body
scene.render.resolution_x=1024; scene.render.resolution_y=1536
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'STREAKFIT-blue-model-v4.blend'),compress=True)

# Linked copies are for the static comparison image only; all share identical skin.
copies=[]
for name,x,angle in [('FRONT',-.87,0),('SIDE',0,math.pi/2),('BACK',.87,math.pi)]:
    ob=body.copy(); ob.data=body.data; ob.name='Review '+name; scene.collection.objects.link(ob)
    ob.location.x=x; ob.rotation_euler.z=angle; copies.append(ob)
body.hide_render=True
d=bpy.data.cameras.new('Three-view review camera'); cam=bpy.data.objects.new('Three-view review camera',d)
scene.collection.objects.link(cam); cam.location=(0,-7,1.08)
cam.rotation_euler=(Vector((0,0,.90))-cam.location).to_track_quat('-Z','Y').to_euler()
d.type='ORTHO'; d.ortho_scale=3.15; scene.camera=cam
scene.render.resolution_x=2304; scene.render.resolution_y=1536
scene.render.filepath=str(OUT/('studio-draft.png' if '--draft' in sys.argv else 'studio-three-view.png'))
# Save linear beauty/albedo/normal passes for an external OIDN build. Blender's
# own binary lacks this denoiser; the official native release digest is checked.
audit=ROOT/'audit'; audit.mkdir(exist_ok=True)
scene.view_layers[0].use_pass_diffuse_color=True
scene.view_layers[0].use_pass_normal=True
scene.use_nodes=True; nt=scene.node_tree; nt.nodes.clear()
rl=nt.nodes.new('CompositorNodeRLayers'); comp=nt.nodes.new('CompositorNodeComposite')
nt.links.new(rl.outputs['Image'],comp.inputs['Image'])
node=nt.nodes.new('CompositorNodeOutputFile'); node.base_path=str(audit/'linear')
node.format.file_format='OPEN_EXR'; node.format.color_depth='32'; node.format.color_mode='RGBA'
node.file_slots[0].path='beauty-'; nt.links.new(rl.outputs['Image'],node.inputs[0])
for name,socket in [('albedo','DiffCol'),('normal','Normal')]:
    node.file_slots.new(name); node.file_slots[-1].path=name+'-'
    nt.links.new(rl.outputs[socket],node.inputs[name])
bpy.ops.render.render(write_still=True)
def read_exr(name):
    image=bpy.data.images.load(str(audit/'linear'/(name+'-0001.exr')),check_existing=False)
    w,h=image.size; pixels=np.empty(w*h*4,dtype=np.float32)
    image.pixels.foreach_get(pixels); return pixels.reshape((h,w,4))
beauty=read_exr('beauty'); height,width=beauty.shape[:2]
def write_pfm(path,rgb):
    with path.open('wb') as f:
        f.write(f'PF\n{width} {height}\n-1.0\n'.encode()); f.write(np.asarray(rgb,dtype='<f4').tobytes())
paths={}
for name,pixels in [('beauty',beauty),('albedo',read_exr('albedo')),('normal',read_exr('normal'))]:
    paths[name]=audit/(name+'.pfm'); write_pfm(paths[name],pixels[:,:,:3])
denoised=audit/'denoised.pfm'
exe=ROOT/'tools/oidn-2.5.1.x86_64.linux/bin/oidnDenoise'
subprocess.run([str(exe),'-d','cpu','--hdr',str(paths['beauty']),'--alb',str(paths['albedo']),
                '--nrm',str(paths['normal']),'-o',str(denoised),'--threads','4','--quality','high'],check=True)
with denoised.open('rb') as f:
    assert f.readline().strip()==b'PF'; assert f.readline().strip()==f'{width} {height}'.encode()
    assert float(f.readline())<0; rgb=np.frombuffer(f.read(),dtype='<f4').reshape((height,width,3)).copy()
rgba=np.concatenate([rgb,beauty[:,:,3:4]],axis=2)
result=bpy.data.images.new('Final denoised studio render',width,height,alpha=True,float_buffer=True)
result.colorspace_settings.name='Linear Rec.709'; result.pixels.foreach_set(rgba.ravel())
result.save_render(scene.render.filepath,scene=scene)
print('STUDIO THREE VIEW RENDER COMPLETE',flush=True)

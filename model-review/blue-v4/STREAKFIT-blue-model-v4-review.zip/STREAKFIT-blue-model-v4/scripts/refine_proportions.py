"""Proportion refinements observed against the actual supplied resting frame."""
import bpy,numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'
body=bpy.data.objects['Blue muscular body · reference reconstruction']
assert 'reference_refinements' not in body, 'Already refined: rebuild base before applying again.'
a=np.empty(len(body.data.vertices)*3,dtype=np.float32);body.data.vertices.foreach_get('co',a);a=a.reshape((-1,3))
x,y,z=a.copy().T;ax=np.abs(x)
def ss(v):
 t=np.clip(v,0,1);return t*t*(3-2*t)
def bump(cx,cz,rx,rz):return np.exp(-2*((ax-cx)/rx)**2-2*((z-cz)/rz)**2)
# Reduce excessive shoulder-to-head span; preserve arm centres and volume.
upper=ss((z-.95)/.10)*(1-ss((z-1.50)/.08))
limbs=ss((ax-.25)/.03)*ss((z-.75)/.05)*(1-ss((z-1.49)/.10))
a[:,0]*=1-.10*np.maximum(upper,limbs)
# Add radial arm fullness around the existing centreline, instead of moving arms.
axis=np.interp(z,[.8,.9,1.0,1.1,1.2,1.3,1.4,1.5],[.386,.380,.357,.335,.308,.279,.244,.200])
arm=ss((ax-.21)/.04)*ss((z-1.13)/.07)*(1-ss((z-1.40)/.08))
a[:,0]+=np.sign(x)*(ax-axis)*.22*arm
a[:,1]+=y*.15*arm
# Slightly broader featureless head; not an isolated ellipsoid object.
head=ss((z-1.575)/.07);a[:,0]*=1+.08*head
# Continuous clavicle and paired neck cords, with deltopectoral separation.
front=ss((-y-.012)/.05)
cord_x=.020+.32*(z-1.45)
cord=np.exp(-2*((ax-cord_x)/.012)**2)*ss((z-1.455)/.020)*(1-ss((z-1.56)/.020))
relief=.008*cord+.008*bump(.100,1.442,.097,.010)
relief-=.006*bump(.204,1.383,.015,.060)
a[:,1]-=relief*front
body.data.vertices.foreach_set('co',a.ravel());body.data.update()
body['reference_refinements']='Resting frame: narrower shoulder-to-head span, fuller arms, wider head, neck/clavicle relief; continuous blue skin, no shorts.'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'STREAKFIT-blue-model-v4.blend'),compress=True)
print('REFERENCE PROPORTION REFINEMENT COMPLETE',flush=True)
